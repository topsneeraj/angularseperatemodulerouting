import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ViewdataModule} from './viewdata/viewdata.module';
import {ApproutingModule} from './approuting/approuting.module';
import { AppComponent } from './app.component';
import { from } from 'rxjs';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    ViewdataModule,
    ApproutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
