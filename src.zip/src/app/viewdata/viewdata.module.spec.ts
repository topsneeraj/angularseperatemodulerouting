import { ViewdataModule } from './viewdata.module';

describe('ViewdataModule', () => {
  let viewdataModule: ViewdataModule;

  beforeEach(() => {
    viewdataModule = new ViewdataModule();
  });

  it('should create an instance', () => {
    expect(viewdataModule).toBeTruthy();
  });
});
