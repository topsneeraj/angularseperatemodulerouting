import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DispComponent } from './disp/disp.component';
import {ViewdataroutingModule} from  '../viewdatarouting/viewdatarouting.module'
import { from } from 'rxjs';

@NgModule({
  imports: [
    CommonModule,
    ViewdataroutingModule
  ],
  exports:[DispComponent],

  declarations: [DispComponent]
})
export class ViewdataModule { }
