import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import { Test1Component } from './test1/test1.component';
import { Test2Component } from './test2/test2.component';
import { from } from 'rxjs';

const app :Routes = [{path:'test1',component:Test1Component},{path:'test2',component:Test2Component}];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(app)
  ],
  declarations: [Test1Component, Test2Component]
})
export class ViewdataroutingModule { }
