import { ViewdataroutingModule } from './viewdatarouting.module';

describe('ViewdataroutingModule', () => {
  let viewdataroutingModule: ViewdataroutingModule;

  beforeEach(() => {
    viewdataroutingModule = new ViewdataroutingModule();
  });

  it('should create an instance', () => {
    expect(viewdataroutingModule).toBeTruthy();
  });
});
