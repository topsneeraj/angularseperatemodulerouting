import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Ex1Component } from './ex1/ex1.component';
import { Ex2Component } from './ex2/ex2.component';
import {RouterModule,Routes} from '@angular/router';
import { from } from 'rxjs';

const app: Routes = [{path:'ex1',component:Ex1Component},{path:'ex2',component:Ex2Component},{path:'',component:Ex1Component}];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(app)
  ],
  exports :[RouterModule],
  declarations: [Ex1Component, Ex2Component]
})
export class ApproutingModule { }
